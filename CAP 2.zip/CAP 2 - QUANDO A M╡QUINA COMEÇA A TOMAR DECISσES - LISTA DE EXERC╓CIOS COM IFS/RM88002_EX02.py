ass = str(input("Informe qual seu nível de assinatura: "))
fat_anual = float(input("Informe seu faturamento anual: "))
bonus = float

ass = ass.upper()

if ass == "BASIC":
    bonus = fat_anual * 0.3
    print("O valor a ser pago é de R$ {:.2f}, referente à 30% sobre o faturamento anual.".format(bonus))
elif ass == "SILVER":
    bonus = fat_anual * 0.2
    print("O valor a ser pago é de R$ {:.2f}, referente à 20% sobre o faturamento anual.".format(bonus))
elif ass == "GOLD":
    bonus = fat_anual * 0.1
    print("O valor a ser pago é de R$ {:.2f}, referente à 10% sobre o faturamento anual.".format(bonus))
else:
    bonus = fat_anual * 0.05
    print("O valor a ser pago é de R$ {:.2f}, referente à 5% sobre o faturamento anual.".format(bonus))
