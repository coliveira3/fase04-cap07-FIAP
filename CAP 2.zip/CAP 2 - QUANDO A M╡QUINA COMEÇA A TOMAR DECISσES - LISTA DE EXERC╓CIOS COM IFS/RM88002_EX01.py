peso = float(input("Digite seu peso em quilos (ex.:85.5): "))
altura = float(input("Digite sua altura em metros (ex.:1.70): "))

imc = float(peso / (altura * altura))

if imc < 16:
    print("Categoria: Baixo peso Grau III.")
elif imc >= 16.00 and imc <= 16.99:
    print("Categoria: Baixo peso Grau II.")
elif imc >= 17.00 and imc <= 18.49:
    print("Categoria: Baixo peso Grau I.")
elif imc >= 18.50 and imc <= 24.99:
    print("Categoria: Peso ideal.")
elif imc >= 25.00 and imc <= 29.99:
    print("Categoria: Sobrepeso.")
elif imc >= 30.00 and imc <= 34.99:
    print("Categoria: Obesidade Grau I.")
elif imc >= 35.00 and imc <= 39.99:
    print("Categoria: Obesidade Grau II.")
else:
    print("Categoria: Obesidade Grau III.")
