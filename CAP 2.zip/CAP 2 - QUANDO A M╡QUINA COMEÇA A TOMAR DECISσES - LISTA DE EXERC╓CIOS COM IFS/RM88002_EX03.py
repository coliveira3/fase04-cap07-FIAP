segunda = int(input("Qual a quantidade de votos para realização de lives às segundas-feiras?: "))
terca = int(input("Qual a quantidade de votos para realização de lives às terças-feiras?: "))
quarta = int(input("Qual a quantidade de votos para realização de lives às quartas-feiras?: "))
quinta = int(input("Qual a quantidade de votos para realização de lives às quintas-feiras?: "))
sexta = int(input("Qual a quantidade de votos para realização de lives às sextas-feiras?: "))

if segunda > terca and segunda > quarta and segunda > quinta and segunda > sexta:
    print("O dia selecionado para a realização das lives foi segunda-feira.")
elif terca > segunda and terca > quarta and terca > quinta and terca > sexta:
    print("O dia selecionado para a realização das lives foi terça-feira.")
elif quarta > terca and quarta > segunda and quarta > quinta and quarta > sexta:
    print("O dia selecionado para a realização das lives foi quarta-feira.")
elif quinta > terca and quinta > quarta and quinta > segunda and quinta > sexta:
    print("O dia selecionado para a realização das lives foi quinta-feira.")
elif sexta > terca and sexta > quarta and sexta > quinta and sexta > segunda:
    print("O dia selecionado para a realização das lives foi sexta-feira.")
else:
    print("Houve empate. Será necessário realizar uma nova votação.")